from django.apps import AppConfig


class AppFavBooksConfig(AppConfig):
    name = 'app_fav_books'
